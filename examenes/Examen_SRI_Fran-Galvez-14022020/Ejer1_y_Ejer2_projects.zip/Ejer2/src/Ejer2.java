import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ButtonGroup;
import javax.swing.JSeparator;
import javax.swing.JCheckBox;
import javax.swing.JSlider;
import javax.swing.JButton;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;

public class Ejer2 {

	private JFrame frame;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private int windows = 0;
	private int linux = 0;
	private int mac = 0;
	private int administracion = 0;
	private int graficos = 0;
	private int coding = 0;
	private int total_encuestas = 0;
	private int total_horas = 0;
	private String mas_escogido = "";
	private int mas_escogido_veces = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ejer2 window = new Ejer2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ejer2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setResizable(false);
		frame.setBounds(100, 100, 315, 445);
		
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				String aux = "";
				if ((administracion > graficos)&&(administracion > coding)) 
					mas_escogido = "Administrac�n";
				if ((graficos > administracion)&&(graficos > coding))
					mas_escogido = "Dise�o gr�fico";
				if ((coding > administracion)&&(coding > graficos))
					mas_escogido = "Programaci�n";
				
				switch (mas_escogido) {
				case "Administraci�n":
					mas_escogido_veces = administracion;
					break;
				case "Dise�o gr�fico":
					mas_escogido_veces = graficos;
					break;
				case "Programaci�n":
					mas_escogido_veces = coding;
					break;
				}
					
				aux += "N�mero total de encuestas: " + total_encuestas + ".\n";
				aux += "N�mero de Windows: " + windows + ".\n";
				aux += "N�mero de Linux: " + linux +".\n";
				aux += "N�mero de MAC: " + mac + ".\n";
				aux += "Especilidad m�s escogida: " + mas_escogido + "y se ha escogido " + mas_escogido_veces + " veces.\n";
				aux += "Media de horas dedicadas al ordenador: " + (total_horas/total_encuestas) + ".";
				
				JOptionPane.showMessageDialog(frame, aux, "Estad�sticas", JOptionPane.OK_OPTION);
			}
		});
		
		JLabel lblSO = new JLabel("Elige un sistema operativo: ");
		
		JRadioButton rdbtnWindows = new JRadioButton("Windows");
		buttonGroup.add(rdbtnWindows);
		
		JRadioButton rdbtnLinux = new JRadioButton("Linux");
		buttonGroup.add(rdbtnLinux);
		
		JRadioButton rdbtnMAC = new JRadioButton("MAC");
		buttonGroup.add(rdbtnMAC);
		
		JSeparator separator = new JSeparator();
		
		JLabel lblEspecialidad = new JLabel("Elige tu especialidad:");
		
		JCheckBox chckbxProgramacion = new JCheckBox("Programaci\u00F3n");
		
		JCheckBox chckbxDisGrafico = new JCheckBox("Dise\u00F1o gr\u00E1fico");
		
		JCheckBox chckbxAdmin = new JCheckBox("Administraci\u00F3n");
		
		JSeparator separator_1 = new JSeparator();
		
		JLabel lblHoras = new JLabel("Horas que dedicas en el ordenador:");
		
		JSlider slider = new JSlider();
		
		slider.setValue(4);
		slider.setMaximum(10);
		
		JLabel lblNewLabel = new JLabel("4");
		
		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				total_encuestas++;
				String os = "Tu sistema operativo preferido es ";
				String esp = "tus especialidades son ";
				String horas = "y el n�mero de horas dedicadad al ordenador son ";
				String aux = "";
				
				if (rdbtnLinux.isSelected()) {
					os += rdbtnLinux.getText();
					linux++;
				}
				if (rdbtnMAC.isSelected()) {
					os += rdbtnMAC.getText();
					mac++;
				}
				if (rdbtnWindows.isSelected()){
					os += rdbtnWindows.getText();
					windows++;
				}
				
				if (chckbxAdmin.isSelected()) {
					esp += chckbxAdmin.getText() + " ";
					administracion++;
				}
				if (chckbxDisGrafico.isSelected()) {
					esp += chckbxDisGrafico.getText() + " ";
					graficos++;
				}
				if (chckbxProgramacion.isSelected()) {
					esp += chckbxProgramacion.getText() + " ";
					coding++;
				}
				
				horas += Integer.valueOf(slider.getValue()).toString();
				total_horas++;
				
				aux = os + "\n" + esp + "\n" + horas + "\n";
				
				JOptionPane.showMessageDialog(frame, aux, "Muestra de datos", JOptionPane.OK_OPTION);
				
			}
		});
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(37)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblHoras)
								.addComponent(chckbxAdmin)
								.addComponent(chckbxDisGrafico)
								.addComponent(chckbxProgramacion)
								.addComponent(lblEspecialidad)
								.addComponent(separator, GroupLayout.PREFERRED_SIZE, 234, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
									.addComponent(rdbtnMAC, Alignment.LEADING)
									.addComponent(rdbtnLinux, Alignment.LEADING)
									.addComponent(rdbtnWindows, Alignment.LEADING)
									.addComponent(lblSO, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addGroup(groupLayout.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(slider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, 234, GroupLayout.PREFERRED_SIZE)))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(113)
							.addComponent(btnEnviar)))
					.addContainerGap(22, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(32)
					.addComponent(lblSO)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnWindows)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(rdbtnLinux)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(rdbtnMAC)
					.addGap(15)
					.addComponent(separator, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblEspecialidad)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(chckbxProgramacion)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(chckbxDisGrafico)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(chckbxAdmin)
					.addGap(18)
					.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lblHoras)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(slider, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(18)
					.addComponent(btnEnviar)
					.addContainerGap(18, Short.MAX_VALUE))
		);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				lblNewLabel.setText(Integer.valueOf(slider.getValue()).toString());
			}
		});
		frame.getContentPane().setLayout(groupLayout);
	}
}
