import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ejer1 {

	private JFrame frmConversorDeMonedas;
	private JTextField textFieldCantidad;
	private JTextField textFieldResultado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ejer1 window = new Ejer1();
					window.frmConversorDeMonedas.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ejer1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmConversorDeMonedas = new JFrame();
		frmConversorDeMonedas.setResizable(false);
		frmConversorDeMonedas.setTitle("Conversor de Monedas");
		frmConversorDeMonedas.setBounds(100, 100, 538, 205);
		frmConversorDeMonedas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblCantidad = new JLabel("Inserte cantidad:");
		
		textFieldCantidad = new JTextField();
		textFieldCantidad.setColumns(10);
		
		textFieldResultado = new JTextField();
		textFieldResultado.setEnabled(false);
		textFieldResultado.setColumns(10);
		
		JButton btnNewButton = new JButton("Convertir");
		
		JLabel lblConvertirDe = new JLabel("De:");
		
		JLabel lblConvertirA = new JLabel("A:");
		
		JComboBox comboBoxConvertirDe = new JComboBox();
		comboBoxConvertirDe.setModel(new DefaultComboBoxModel(new String[] {"Seleccione moneda", "Euros", "D\u00F3lares", "Libras"}));
		comboBoxConvertirDe.setSelectedIndex(0);
		
		JComboBox comboBoxConvertirA = new JComboBox();
		comboBoxConvertirA.setModel(new DefaultComboBoxModel(new String[] {"Seleccione moneda", "Euros", "D\u00F3lares", "Libras"}));
		comboBoxConvertirA.setSelectedIndex(0);
		
		JLabel lblResultado = new JLabel("Resultado:");
		GroupLayout groupLayout = new GroupLayout(frmConversorDeMonedas.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(41)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnNewButton)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblCantidad)
								.addComponent(lblResultado))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(textFieldCantidad, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(textFieldResultado, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
					.addGap(52)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblConvertirDe)
						.addComponent(lblConvertirA))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(comboBoxConvertirDe, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(comboBoxConvertirA, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(32, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(36)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCantidad)
						.addComponent(textFieldCantidad, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblConvertirDe)
						.addComponent(comboBoxConvertirDe, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(textFieldResultado, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblConvertirA)
						.addComponent(lblResultado)
						.addComponent(comboBoxConvertirA, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(btnNewButton)
					.addContainerGap(22, Short.MAX_VALUE))
		);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				final double eurolibra = 0.75;
				final double eurodolar = 1.25;
				final double dolarlibra = 0.5;
				
				double cantidad = Double.valueOf(textFieldCantidad.getText());
				String convertirDe = comboBoxConvertirDe.getSelectedItem().toString();
				String convertirA = comboBoxConvertirA.getSelectedItem().toString();
				double resultado = 0;
								
				if (convertirDe == convertirA)
					//JOptionPane.showMessageDialog(frmConversorDeMonedas, "No se puede realizar la conversi�n a la misma divisa.");
					textFieldResultado.setText("No se puede convertir.");
				else {
					switch (convertirDe) {
						case "Euros":
							switch (convertirA) {
								case "D�lares":
									resultado = cantidad * eurodolar;
									textFieldResultado.setText(Double.valueOf(resultado).toString());
									break;
								case "Libras":
									resultado = cantidad * eurolibra;
									textFieldResultado.setText(Double.valueOf(resultado).toString());
									break;
							}
							break;
						case "D�lares":
							switch (convertirA) {
								case "Euros":
									resultado = cantidad / eurodolar;
									textFieldResultado.setText(Double.valueOf(resultado).toString());
									break;
								case "Libras":
									resultado = cantidad * dolarlibra;
									textFieldResultado.setText(Double.valueOf(resultado).toString());
									break;
							}
							break;
						case "Libras":
							switch (convertirA) {
								case "Euros":
									resultado = cantidad / eurolibra;
									textFieldResultado.setText(Double.valueOf(resultado).toString());
									break;
								case "D�lares":
									resultado = cantidad / dolarlibra;
									textFieldResultado.setText(Double.valueOf(resultado).toString());
									break;
							}
							break;
					}
				}
				comboBoxConvertirA.setSelectedIndex(0);
				comboBoxConvertirDe.setSelectedIndex(0);
			}
		});
		
		frmConversorDeMonedas.getContentPane().setLayout(groupLayout);
	}
}
